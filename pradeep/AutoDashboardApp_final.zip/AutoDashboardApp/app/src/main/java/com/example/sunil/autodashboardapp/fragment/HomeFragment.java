package com.example.sunil.autodashboardapp.fragment;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

import com.example.sunil.autodashboardapp.R;
import com.example.sunil.autodashboardapp.app.CustomGrid;
import com.example.sunil.autodashboardapp.iconfragment.FileFragment;
import com.example.sunil.autodashboardapp.iconfragment.GalleryFragment;
import com.example.sunil.autodashboardapp.iconfragment.MapFragment;
import com.example.sunil.autodashboardapp.iconfragment.MeterIconFragment;
import com.example.sunil.autodashboardapp.iconfragment.MovFragment;
import com.example.sunil.autodashboardapp.iconfragment.MusicFragment;
import com.example.sunil.autodashboardapp.iconfragment.SettingsFragment;
import com.example.sunil.autodashboardapp.iconfragment.WebviewFragment;


public class HomeFragment extends Fragment {
    GridView grid;
    int[] imageId = {
            R.drawable.fe,
            R.drawable.gal,
            R.drawable.loc,
            R.drawable.set,
            R.drawable.sep,
            R.drawable.mov,
            R.drawable.mus,
            R.drawable.web };
    String[] web = {
            "file",
            "gallery",
            "map",
            "settings",
            "meter",
            "mov",
            "mus",
            "web",

    } ;

    public HomeFragment() {
        // Required empty public constructor
    }

    public static HomeFragment newInstance(String param1, String param2) {
        HomeFragment fragment = new HomeFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_home, container, false);
        CustomGrid adapter = new CustomGrid(this.getActivity(),imageId);
        grid = v.findViewById(R.id.grid);
        grid.setAdapter(adapter);
        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                Toast.makeText(getActivity(), "You Clicked at " +web[+ position] , Toast.LENGTH_SHORT).show();

                if(web[position].equals("web"))
                {
                    Intent launchYouTube = getActivity().getPackageManager().getLaunchIntentForPackage("com.example.sunil.sampleapp");
                    startActivity(launchYouTube);
                }else
                if(web[position].equals("map"))
                {
                    Intent launchYouTube1 = getActivity().getPackageManager().getLaunchIntentForPackage("com.example.sunil.sampleapp");
                    startActivity(launchYouTube1);

                }
                if(web[position].equals("file"))
                {
                    Intent launchYouTube = getActivity().getPackageManager().getLaunchIntentForPackage("com.example.sunil.sampleapp");
                    startActivity(launchYouTube);
                }

                if(web[position].equals("gallery"))
                {
                    Intent launchYouTube = getActivity().getPackageManager().getLaunchIntentForPackage("com.example.sunil.sampleapp");
                    startActivity(launchYouTube);
                }

                if(web[position].equals("mus"))
                {
                    Intent launchYouTube2 = getActivity().getPackageManager().getLaunchIntentForPackage("com.example.sunil.sampleapp");
                    startActivity(launchYouTube2);
                }
                if(web[position].equals("settings"))
                {
                    Intent launchYouTube = getActivity().getPackageManager().getLaunchIntentForPackage("com.example.sunil.sampleapp");
                    startActivity(launchYouTube);
                }
                if(web[position].equals("mov"))
                {
                    Intent launchYouTube = getActivity().getPackageManager().getLaunchIntentForPackage("com.example.sunil.sampleapp");
                    startActivity(launchYouTube);
                }
                if(web[position].equals("meter"))
                {
                    Intent launchYouTube3 = getActivity().getPackageManager().getLaunchIntentForPackage("com.example.sunil.sampleapp");
                    startActivity(launchYouTube3);
                }
            }
        });
        return v;

    }

    /**
     * loading fragment into FrameLayout
     *
     * @param fragment
     */
    private void loadFragment(Fragment fragment) {
        // load fragment
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.frame_container, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }
}
